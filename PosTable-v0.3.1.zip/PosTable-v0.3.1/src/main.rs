use std::collections::BTreeMap;
use std::env;
use std::fs::{self, File, OpenOptions};
use std::io::{self, BufRead, BufReader, Read, Write};
use std::net::{TcpListener, TcpStream};
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex};
use std::thread;

const VERSION: &str = "0.3.1";
const DEFAULT_ADDR: &str = "127.0.0.1:5433";
const SNAPSHOT_THRESHOLD: usize = 1000;

#[derive(Clone, Debug, PartialEq)]
enum Value { Int(i64), Text(String), Bool(bool), Null }
#[derive(Clone, Debug, PartialEq)]
enum ColType { Int, Text, Bool }
#[derive(Clone, Debug)]
struct Column { name: String, ty: ColType }
#[derive(Clone, Debug)]
struct Table { columns: Vec<Column>, rows: Vec<Vec<Value>> }
impl Table {
    fn row_at(&self, index: usize) -> Result<&[Value], String> {
        self.rows.get(index).map(Vec::as_slice).ok_or_else(|| "row index out of range".into())
    }
}
#[derive(Clone, Debug, Default)]
struct Database { tables: BTreeMap<String, Table> }
#[derive(Clone, Debug, Default)]
struct State { dbs: BTreeMap<String, Database>, current_db: Option<String> }

#[derive(Clone)]
struct Engine { state: Arc<Mutex<State>>, root: PathBuf }

fn crc32(bytes: &[u8]) -> u32 {
    let mut crc = 0xffff_ffffu32;
    for &b in bytes {
        crc ^= b as u32;
        for _ in 0..8 { crc = if crc & 1 != 0 { (crc >> 1) ^ 0xedb88320 } else { crc >> 1 }; }
    }
    !crc
}
fn hex_u32(v: u32) -> String { format!("{:08x}", v) }
fn parse_hex_u32(s: &str) -> Option<u32> { u32::from_str_radix(s, 16).ok() }

fn put_u32(out: &mut Vec<u8>, v: u32) { out.extend_from_slice(&v.to_le_bytes()); }
fn put_u64(out: &mut Vec<u8>, v: u64) { out.extend_from_slice(&v.to_le_bytes()); }
fn get_u32(data: &[u8], p: &mut usize) -> io::Result<u32> { if data.len().saturating_sub(*p)<4 {return Err(io::Error::new(io::ErrorKind::UnexpectedEof,"u32"));} let mut a=[0;4];a.copy_from_slice(&data[*p..*p+4]);*p+=4;Ok(u32::from_le_bytes(a)) }
fn get_u64(data: &[u8], p: &mut usize) -> io::Result<u64> { if data.len().saturating_sub(*p)<8 {return Err(io::Error::new(io::ErrorKind::UnexpectedEof,"u64"));} let mut a=[0;8];a.copy_from_slice(&data[*p..*p+8]);*p+=8;Ok(u64::from_le_bytes(a)) }
fn put_str(out:&mut Vec<u8>,s:&str){put_u32(out,s.len() as u32);out.extend_from_slice(s.as_bytes());}
fn get_str(data:&[u8],p:&mut usize)->io::Result<String>{let n=get_u32(data,p)? as usize;if data.len().saturating_sub(*p)<n{return Err(io::Error::new(io::ErrorKind::UnexpectedEof,"str"));}let s=String::from_utf8(data[*p..*p+n].to_vec()).map_err(|_|io::Error::new(io::ErrorKind::InvalidData,"utf8"))?;*p+=n;Ok(s)}

fn encode_state(s:&State)->Vec<u8>{
    let mut o=Vec::new();o.extend_from_slice(b"PST1");put_u32(&mut o,s.dbs.len() as u32);
    for (dn,db) in &s.dbs {put_str(&mut o,dn);put_u32(&mut o,db.tables.len() as u32);for (tn,t) in &db.tables{put_str(&mut o,tn);put_u32(&mut o,t.columns.len() as u32);for c in &t.columns{put_str(&mut o,&c.name);o.push(match c.ty{ColType::Int=>1,ColType::Text=>2,ColType::Bool=>3});}put_u64(&mut o,t.rows.len() as u64);for r in &t.rows{put_u32(&mut o,r.len() as u32);for v in r{match v{Value::Int(x)=>{o.push(1);o.extend_from_slice(&x.to_le_bytes())},Value::Text(x)=>{o.push(2);put_str(&mut o,x)},Value::Bool(x)=>{o.push(3);o.push(*x as u8)},Value::Null=>o.push(0)}}}}}}
    o
}
fn decode_state(d:&[u8])->io::Result<State>{let mut p=0;if d.get(0..4)!=Some(b"PST1"){return Err(io::Error::new(io::ErrorKind::InvalidData,"bad snapshot magic"));}p=4;let n=get_u32(d,&mut p)?;let mut dbs=BTreeMap::new();for _ in 0..n{let dn=get_str(d,&mut p)?;let nt=get_u32(d,&mut p)?;let mut tables=BTreeMap::new();for _ in 0..nt{let tn=get_str(d,&mut p)?;let nc=get_u32(d,&mut p)?;let mut cols=Vec::new();for _ in 0..nc{let name=get_str(d,&mut p)?;let ty=match *d.get(p).ok_or_else(||io::Error::new(io::ErrorKind::UnexpectedEof,"type"))?{1=>ColType::Int,2=>ColType::Text,3=>ColType::Bool,_=>return Err(io::Error::new(io::ErrorKind::InvalidData,"type"))};p+=1;cols.push(Column{name,ty});}let nr=get_u64(d,&mut p)? as usize;let mut rows=Vec::with_capacity(nr);for _ in 0..nr{let nv=get_u32(d,&mut p)? as usize;let mut r=Vec::with_capacity(nv);for _ in 0..nv{let tag=*d.get(p).ok_or_else(||io::Error::new(io::ErrorKind::UnexpectedEof,"value"))?;p+=1;let v=match tag{0=>Value::Null,1=>{let x=get_u64(d,&mut p)? as i64;Value::Int(x)},2=>Value::Text(get_str(d,&mut p)?),3=>{let x=*d.get(p).ok_or_else(||io::Error::new(io::ErrorKind::UnexpectedEof,"bool"))?;p+=1;Value::Bool(x!=0)},_=>return Err(io::Error::new(io::ErrorKind::InvalidData,"value"))};r.push(v)}rows.push(r)}tables.insert(tn,Table{columns:cols,rows});}dbs.insert(dn,Database{tables});}Ok(State{dbs,current_db:None})}

impl Engine {
    fn new(root: impl Into<PathBuf>) -> io::Result<Self> { let root=root.into();fs::create_dir_all(&root)?;let mut s=State::default();let snap=root.join("snapshot.dat");if snap.exists(){let mut b=Vec::new();File::open(&snap)?.read_to_end(&mut b)?;if let Ok(x)=decode_state(&b){s=x;}}let e=Self{state:Arc::new(Mutex::new(s)),root};e.replay_wal()?;Ok(e) }
    fn wal_path(&self)->PathBuf{self.root.join("wal.log")}
    fn append_wal(&self,cmd:&str)->Result<(),String>{let mut f=OpenOptions::new().create(true).append(true).open(self.wal_path()).map_err(|e|e.to_string())?;let c=hex_u32(crc32(cmd.as_bytes()));writeln!(f,"{}\t{}",cmd.replace('\n'," "),c).map_err(|e|e.to_string())?;f.sync_all().map_err(|e|e.to_string())?;Ok(())}
    fn replay_wal(&self)->io::Result<()>{let p=self.wal_path();if !p.exists(){return Ok(())}let f=File::open(p)?;for line in BufReader::new(f).lines(){let line=line?;let Some((cmd,cs))=line.rsplit_once('\t') else{eprintln!("PosTable: malformed WAL record ignored");continue};let Some(want)=parse_hex_u32(cs.trim()) else{eprintln!("PosTable: bad WAL CRC ignored");continue};if crc32(cmd.as_bytes())!=want{eprintln!("PosTable: CRC mismatch; record ignored");continue}let _=self.execute_internal(cmd,false); }Ok(())}
    fn snapshot(&self)->Result<(),String>{let s=self.state.lock().map_err(|_|"state poisoned".to_string())?.clone();let tmp=self.root.join("snapshot.dat.tmp");let finalp=self.root.join("snapshot.dat");let mut f=OpenOptions::new().create(true).truncate(true).write(true).open(&tmp).map_err(|e|e.to_string())?;f.write_all(&encode_state(&s)).map_err(|e|e.to_string())?;f.sync_all().map_err(|e|e.to_string())?;fs::rename(&tmp,&finalp).map_err(|e|e.to_string())?;let dir=File::open(&self.root).map_err(|e|e.to_string())?;let _=dir.sync_all();let _=fs::remove_file(self.wal_path());Ok(())}
    fn execute(&self,sql:&str)->Result<String,String>{let out=self.execute_internal(sql,true)?;Ok(out)}
    fn execute_internal(&self,sql:&str,log:bool)->Result<String,String>{let cmd=sql.trim().trim_end_matches(';').trim();if cmd.is_empty(){return Ok("OK".into())}let upper=cmd.to_ascii_uppercase();if upper=="SHOW DATABASES"{let s=self.state.lock().map_err(|_|"state poisoned")?;return Ok(s.dbs.keys().cloned().collect::<Vec<_>>().join("\n"));}
        let mut state=self.state.lock().map_err(|_|"state poisoned")?;
        if upper.starts_with("CREATE DATABASE "){let n=cmd[16..].trim();valid_name(n)?;if state.dbs.contains_key(n){return Err("database already exists".into())}state.dbs.insert(n.to_string(),Database::default());drop(state);if log{self.append_wal(cmd)?;}return Ok("OK".into())}
        if upper.starts_with("USE "){let n=cmd[4..].trim();if !state.dbs.contains_key(n){return Err("database not found".into())}state.current_db=Some(n.to_string());return Ok(format!("OK: {}",n))}
        let dbn=state.current_db.clone().ok_or("select a database with USE")?;
        let db=state.dbs.get_mut(&dbn).ok_or("database not found")?;
        if upper.starts_with("CREATE TABLE "){let rest=&cmd[13..];let (name,defs)=rest.split_once('(').ok_or("expected columns")?;let name=name.trim();valid_name(name)?;if db.tables.contains_key(name){return Err("table already exists".into())}let defs=defs.trim().strip_suffix(')').ok_or("missing )")?;let mut cols=Vec::new();for d in split_csv(defs){let mut it=d.split_whitespace();let cn=it.next().ok_or("bad column")?;let ct=it.next().ok_or("missing type")?;valid_name(cn)?;let ty=match ct.to_ascii_uppercase().as_str(){"INT"|"INTEGER"=>ColType::Int,"TEXT"|"STRING"=>ColType::Text,"BOOL"|"BOOLEAN"=>ColType::Bool,_=>return Err("unsupported type".into())};if cols.iter().any(|c: &Column| c.name.eq_ignore_ascii_case(cn)){return Err("duplicate column".into())}cols.push(Column{name:cn.into(),ty});}if cols.is_empty(){return Err("no columns".into())}db.tables.insert(name.into(),Table{columns:cols,rows:Vec::new()});drop(state);if log{self.append_wal(cmd)?;}return Ok("OK".into())}
        if upper.starts_with("DROP TABLE "){let n=cmd[11..].trim();if db.tables.remove(n).is_none(){return Err("table not found".into())}drop(state);if log{self.append_wal(cmd)?;}return Ok("OK".into())}
        if upper.starts_with("INSERT INTO "){let rest=&cmd[12..];let (tn,vals)=rest.split_once(" VALUES ").or_else(||rest.split_once(" values ")).ok_or("expected VALUES")?;let tn=tn.trim();let table=db.tables.get(tn).ok_or("table not found")?.clone();let body=vals.trim().strip_prefix('(').and_then(|x|x.strip_suffix(')')).ok_or("bad VALUES")?;let raw=split_csv(body);if raw.len()!=table.columns.len(){return Err("column count mismatch".into())}let row=parse_row(&table.columns,&raw)?;let t=db.tables.get_mut(tn).unwrap();t.rows.push(row);drop(state);if log{self.append_wal(cmd)?;}if log{self.maybe_snapshot();}return Ok("OK".into())}
        if upper.starts_with("SELECT "){drop(state);return self.select(cmd)}
        if upper.starts_with("UPDATE "){let (tn,setpart,wherepart)=parse_update(cmd)?;let table=db.tables.get(tn).ok_or("table not found")?.clone();let setcol=setpart.split_once('=').ok_or("bad SET")?;let idx=find_col(&table.columns,setcol.0.trim())?;let newv=parse_value(&table.columns[idx].ty,setcol.1.trim())?;let targets=matching_indices(&table,wherepart)?;let mut candidate=table.clone();for i in &targets{candidate.rows[*i][idx]=newv.clone();}db.tables.insert(tn.to_string(),candidate);drop(state);if log{self.append_wal(cmd)?;self.maybe_snapshot();}return Ok(format!("OK: {} rows",targets.len()))}
        if upper.starts_with("DELETE FROM "){let (tn,wherepart)=parse_delete(cmd)?;let table=db.tables.get(tn).ok_or("table not found")?.clone();let targets=matching_indices(&table,wherepart)?;let mut candidate=table.clone();let mut keep=Vec::with_capacity(candidate.rows.len());for (i,r) in candidate.rows.into_iter().enumerate(){if !targets.contains(&i){keep.push(r)}}candidate.rows=keep;db.tables.insert(tn.to_string(),candidate);drop(state);if log{self.append_wal(cmd)?;self.maybe_snapshot();}return Ok(format!("OK: {} rows",targets.len()))}
        Err("unsupported SQL".into())
    }
    fn maybe_snapshot(&self){if let Ok(m)=fs::metadata(self.wal_path()){if m.len() > 1024*1024{let _=self.snapshot();}}}
    fn select(&self,cmd:&str)->Result<String,String>{let state=self.state.lock().map_err(|_|"state poisoned")?;let dbn=state.current_db.clone().ok_or("select a database with USE")?;let db=state.dbs.get(&dbn).ok_or("database not found")?;let up=cmd.to_ascii_uppercase();let from=up.find(" FROM ").ok_or("expected FROM")?;let projection=cmd[7..from].trim();let after=&cmd[from+6..];let (tn,wp)=split_where(after);let t=db.tables.get(tn.trim()).ok_or("table not found")?;let indices=matching_indices(t,wp)?;let wanted:Vec<usize>=if projection=="*"{(0..t.columns.len()).collect()}else{projection.split(',').map(|x|find_col(&t.columns,x.trim())).collect::<Result<_,_>>()?};let mut out=Vec::new();out.push(wanted.iter().map(|i|t.columns[*i].name.clone()).collect::<Vec<_>>().join(" | "));for ri in indices{let r=t.row_at(ri)?;out.push(wanted.iter().map(|i|display(&r[*i])).collect::<Vec<_>>().join(" | "));}Ok(out.join("\n"))}
}

fn valid_name(s:&str)->Result<(),String>{if s.is_empty()||!s.chars().all(|c|c.is_ascii_alphanumeric()||c=='_'){Err("invalid identifier".into())}else{Ok(())}}
fn split_csv(s:&str)->Vec<String>{let mut v=Vec::new();let mut cur=String::new();let mut q=false;for c in s.chars(){if c=='\''{q=!q;cur.push(c)}else if c==','&&!q{v.push(cur.trim().to_string());cur.clear()}else{cur.push(c)}}if !cur.trim().is_empty(){v.push(cur.trim().to_string())}v}
fn parse_value(ty:&ColType,s:&str)->Result<Value,String>{let x=s.trim();if x.eq_ignore_ascii_case("NULL"){return Ok(Value::Null)}match ty{ColType::Int=>x.parse::<i64>().map(Value::Int).map_err(|_|"invalid INT".into()),ColType::Bool=>match x.to_ascii_lowercase().as_str(){"true"|"1"=>Ok(Value::Bool(true)),"false"|"0"=>Ok(Value::Bool(false)),_=>Err("invalid BOOL".into())},ColType::Text=>{let y=x.strip_prefix('\'').and_then(|z|z.strip_suffix('\'')).unwrap_or(x);Ok(Value::Text(y.replace("''","'")))}}
fn parse_row(cols:&[Column],raw:&[String])->Result<Vec<Value>,String>{cols.iter().zip(raw).map(|(c,x)|parse_value(&c.ty,x)).collect()}
fn find_col(cols:&[Column],name:&str)->Result<usize,String>{cols.iter().position(|c|c.name.eq_ignore_ascii_case(name)).ok_or_else(||format!("column not found: {}",name))}
fn split_where(s:&str)->(&str,Option<&str>){if let Some(i)=s.to_ascii_uppercase().find(" WHERE "){(&s[..i],Some(s[i+7..].trim()))}else{(s.trim(),None)}}
fn matching_indices(t:&Table,w:Option<&str>)->Result<Vec<usize>,String>{let Some(w)=w else{return Ok((0..t.rows.len()).collect())};let (c,v)=w.split_once('=').ok_or("WHERE supports column = value")?;let i=find_col(&t.columns,c.trim())?;let val=parse_value(&t.columns[i].ty,v.trim())?;Ok(t.rows.iter().enumerate().filter_map(|(n,r)|if r[i]==val{Some(n)}else{None}).collect())}
fn parse_update(s:&str)->Result<(&str,&str,Option<&str>),String>{let rest=&s[7..];let up=rest.to_ascii_uppercase();let set=up.find(" SET ").ok_or("expected SET")?;let tn=rest[..set].trim();let after=&rest[set+5..];let (sp,wp)=split_where(after);Ok((tn,sp,wp))}
fn parse_delete(s:&str)->Result<(&str,Option<&str>),String>{let rest=&s[11..];let (tn,wp)=split_where(rest);Ok((tn.trim(),wp))}
fn display(v:&Value)->String{match v{Value::Int(x)=>x.to_string(),Value::Text(x)=>x.clone(),Value::Bool(x)=>x.to_string(),Value::Null=>"NULL".into()}}

fn handle_client(mut stream:TcpStream,engine:Engine){let peer=stream.peer_addr().ok();let cloned=match stream.try_clone(){Ok(x)=>x,Err(e)=>{eprintln!("client {:?}: {}",peer,e);return}};let reader=BufReader::new(cloned);for line in reader.lines(){let Ok(sql)=line else{break};let response=match engine.execute(&sql){Ok(x)=>format!("OK\n{}\nEND\n",x),Err(e)=>format!("ERROR\n{}\nEND\n",e)};if stream.write_all(response.as_bytes()).is_err(){break}}}
fn run_server(engine:Engine,addr:&str)->io::Result<()>{let listener=TcpListener::bind(addr)?;println!("PosTable {} listening on {}",VERSION,addr);for incoming in listener.incoming(){match incoming{Ok(stream)=>{let e=engine.clone();thread::spawn(move||handle_client(stream,e));}Err(e)=>eprintln!("accept error: {}",e)}}Ok(())}
fn main(){let args:Vec<String>=env::args().collect();let root=env::var("POSTABLE_DATA").unwrap_or_else(|_|"data".into());let engine=match Engine::new(root){Ok(e)=>e,Err(e)=>{eprintln!("startup error: {}",e);std::process::exit(1)}};match args.get(1).map(String::as_str){Some("server")|None=>{if let Err(e)=run_server(engine,DEFAULT_ADDR){eprintln!("server error: {}",e)}},Some("sql")=>{let sql=args[2..].join(" ");match engine.execute(&sql){Ok(x)=>println!("{}",x),Err(e)=>{eprintln!("ERROR: {}",e);std::process::exit(2)}}},Some("snapshot")=>match engine.snapshot(){Ok(())=>println!("snapshot complete"),Err(e)=>eprintln!("snapshot error: {}",e)},Some(x)=>eprintln!("unknown command: {}",x)}}

#[cfg(test)]
mod tests{use super::*;
#[test]fn crc_known(){assert_eq!(hex_u32(crc32(b"123456789")),"cbf43926");}
#[test]fn row_at_is_safe(){let t=Table{columns:vec![],rows:vec![vec![]]};assert!(t.row_at(0).is_ok());assert!(t.row_at(1).is_err());}
#[test]fn snapshot_roundtrip(){let mut s=State::default();s.dbs.insert("demo".into(),Database{tables:BTreeMap::from([("t".into(),Table{columns:vec![Column{name:"id".into(),ty:ColType::Int}],rows:vec![vec![Value::Int(7)]]})])});let b=encode_state(&s);let d=decode_state(&b).unwrap();assert_eq!(d.dbs["demo"].tables["t"].rows[0][0],Value::Int(7));}
#[test]fn atomic_update_validation(){let root=std::env::temp_dir().join(format!("postable-test-{}",std::process::id()));let _=fs::remove_dir_all(&root);let e=Engine::new(&root).unwrap();e.execute("CREATE DATABASE demo").unwrap();e.execute("USE demo").unwrap();e.execute("CREATE TABLE t (id INT, name TEXT)").unwrap();e.execute("INSERT INTO t VALUES (1, 'a')").unwrap();assert!(e.execute("UPDATE t SET id = nope").is_err());let out=e.execute("SELECT * FROM t").unwrap();assert!(out.contains("1 | a"));let _=fs::remove_dir_all(root);}
}
