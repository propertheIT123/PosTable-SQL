# PosTable v0.3.1

Лёгкая учебно-практическая SQL-СУБД на Rust без внешних зависимостей.

## Что есть
- базы данных и таблицы;
- типы `INT`, `TEXT`, `BOOL`;
- `CREATE DATABASE`, `USE`, `CREATE TABLE`, `DROP TABLE`;
- `INSERT`, `SELECT`, `UPDATE`, `DELETE`;
- простой `WHERE column = value`;
- TCP-сервер на `127.0.0.1:5433`;
- дисковый snapshot;
- WAL с CRC32;
- атомарный snapshot через `.tmp` + rename;
- безопасные `UPDATE`/`DELETE`: изменения применяются только после полной валидации;
- `row_at()` без panic при неверном индексе;
- обработка сетевых ошибок без падения всего сервера;
- unit-тесты для CRC, WAL и индекса строки.

## Запуск
```bash
cargo run -- server
```

По умолчанию данные находятся в `data/`.

## Одноразовый SQL из CLI
```bash
cargo run -- sql "CREATE DATABASE demo"
cargo run -- sql "USE demo"
```

TCP-протокол: одна SQL-команда на строку, ответ сервера заканчивается `END`.

Пример через netcat:
```text
CREATE DATABASE demo
USE demo
CREATE TABLE users (id INT, name TEXT)
INSERT INTO users VALUES (1, 'Artem')
SELECT * FROM users
```

## Проверка
На машине с установленным Rust:
```bash
cargo fmt -- --check
cargo test
cargo clippy -- -D warnings
cargo build --release
```

> В текущем рабочем окружении Rust toolchain отсутствует, поэтому эти команды здесь не запускались. Исходники и тесты подготовлены для проверки обычным Cargo.
