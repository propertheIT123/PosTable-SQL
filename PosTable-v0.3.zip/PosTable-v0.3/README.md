# PosTable v0.3

Rust SQL database engine with a separate TCP server, persistent storage, CRC32-protected WAL, atomic batch UPDATE/DELETE and automatic snapshot compaction.

## Build
```bash
cargo build --release
```

## Local CLI
```bash
cargo run --bin postable
```

## Server
```bash
cargo run --bin postable-server
```
Port: `5433`.

## Disk layout
```text
data/demo/snapshot.dat
data/demo/wal.log
```

The engine loads `snapshot.dat` first, then replays only the remaining WAL. At 10,000 WAL records it writes a temporary binary snapshot, syncs it, atomically renames it to `snapshot.dat`, then removes the old WAL.

Each WAL record has `JSON<TAB>CRC32`. A truncated or corrupted record is warned about and ignored instead of crashing startup.

Mass UPDATE/DELETE operations are prepared in a private vector and every resulting row is validated before a single `Batch` WAL record is written. Thus a validation failure changes neither the real table nor the WAL.

`Table::row_at(index)` uses `Vec::get(index)`: direct O(1) indexed access without scanning the vector.

This is a serious durable prototype, not yet production-grade: authentication/TLS, MVCC/isolation levels, indexes/query planning, richer SQL and a true page-based storage engine remain future work.
