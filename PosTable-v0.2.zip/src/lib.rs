use anyhow::{anyhow, Context, Result};
use regex::Regex;
use serde::{Deserialize, Serialize};
use std::{
    collections::{BTreeMap, HashMap},
    fs::{self, File, OpenOptions},
    io::{BufRead, BufReader, Write},
    path::{Path, PathBuf},
    sync::{Arc, Mutex},
};

pub type Row = BTreeMap<String, Value>;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum Value {
    Null,
    Int(i64),
    Text(String),
}

impl Value {
    pub fn display(&self) -> String {
        match self {
            Value::Null => "NULL".into(),
            Value::Int(n) => n.to_string(),
            Value::Text(s) => s.clone(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ColumnType { Int, Text }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Column { pub name: String, pub ty: ColumnType }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Table {
    pub columns: Vec<Column>,
    pub rows: Vec<Row>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Database {
    pub name: String,
    pub tables: HashMap<String, Table>,
}

#[derive(Debug, Serialize, Deserialize)]
enum WalRecord {
    CreateTable { db: String, table: String, columns: Vec<Column> },
    DropTable { db: String, table: String },
    Insert { db: String, table: String, row: Row },
    Update { db: String, table: String, index: usize, row: Row },
    Delete { db: String, table: String, index: usize },
}

#[derive(Clone)]
pub struct Engine {
    root: PathBuf,
    dbs: Arc<Mutex<HashMap<String, Database>>>,
}

impl Engine {
    pub fn open(root: impl AsRef<Path>) -> Result<Self> {
        let root = root.as_ref().to_path_buf();
        fs::create_dir_all(&root)?;
        let engine = Self { root, dbs: Arc::new(Mutex::new(HashMap::new())) };
        engine.load_all()?;
        Ok(engine)
    }

    fn load_all(&self) -> Result<()> {
        let mut guard = self.dbs.lock().unwrap();
        for entry in fs::read_dir(&self.root)? {
            let entry = entry?;
            if !entry.file_type()?.is_dir() { continue; }
            let name = entry.file_name().to_string_lossy().to_string();
            let db = Database { name: name.clone(), tables: HashMap::new() };
            guard.insert(name.clone(), db);
            drop(guard);
            self.replay_wal(&name)?;
            guard = self.dbs.lock().unwrap();
        }
        Ok(())
    }

    fn db_path(&self, db: &str) -> PathBuf { self.root.join(db) }
    fn wal_path(&self, db: &str) -> PathBuf { self.db_path(db).join("wal.log") }

    fn replay_wal(&self, db: &str) -> Result<()> {
        let path = self.wal_path(db);
        if !path.exists() { return Ok(()); }
        let f = File::open(path)?;
        for line in BufReader::new(f).lines() {
            let line = line?;
            if line.trim().is_empty() { continue; }
            let rec: WalRecord = serde_json::from_str(&line)?;
            self.apply_record(rec)?;
        }
        Ok(())
    }

    fn append(&self, rec: &WalRecord) -> Result<()> {
        let db = match rec {
            WalRecord::CreateTable{db,..} | WalRecord::DropTable{db,..} |
            WalRecord::Insert{db,..} | WalRecord::Update{db,..} |
            WalRecord::Delete{db,..} => db,
        };
        fs::create_dir_all(self.db_path(db))?;
        let mut f = OpenOptions::new().create(true).append(true).open(self.wal_path(db))?;
        serde_json::to_writer(&mut f, rec)?;
        f.write_all(b"\n")?;
        f.sync_data()?;
        Ok(())
    }

    fn apply_record(&self, rec: WalRecord) -> Result<()> {
        let mut dbs = self.dbs.lock().unwrap();
        match rec {
            WalRecord::CreateTable{db,table,columns} => {
                let d = dbs.get_mut(&db).ok_or_else(|| anyhow!("database not found: {db}"))?;
                d.tables.entry(table).or_insert(Table { columns, rows: vec![] });
            }
            WalRecord::DropTable{db,table} => {
                if let Some(d) = dbs.get_mut(&db) { d.tables.remove(&table); }
            }
            WalRecord::Insert{db,table,row} => {
                let d = dbs.get_mut(&db).ok_or_else(|| anyhow!("database not found: {db}"))?;
                d.tables.get_mut(&table).ok_or_else(|| anyhow!("table not found: {table}"))?.rows.push(row);
            }
            WalRecord::Update{db,table,index,row} => {
                let d = dbs.get_mut(&db).ok_or_else(|| anyhow!("database not found: {db}"))?;
                d.tables.get_mut(&table).ok_or_else(|| anyhow!("table not found: {table}"))?.rows[index] = row;
            }
            WalRecord::Delete{db,table,index} => {
                let d = dbs.get_mut(&db).ok_or_else(|| anyhow!("database not found: {db}"))?;
                d.tables.get_mut(&table).ok_or_else(|| anyhow!("table not found: {table}"))?.rows.remove(index);
            }
        }
        Ok(())
    }

    pub fn create_database(&self, name: &str) -> Result<()> {
        if !valid_ident(name) { return Err(anyhow!("invalid database name")); }
        let mut dbs = self.dbs.lock().unwrap();
        if dbs.contains_key(name) { return Err(anyhow!("database already exists")); }
        fs::create_dir_all(self.db_path(name))?;
        dbs.insert(name.into(), Database{name:name.into(),tables:HashMap::new()});
        Ok(())
    }

    pub fn drop_database(&self, name: &str) -> Result<()> {
        let mut dbs = self.dbs.lock().unwrap();
        if dbs.remove(name).is_none() { return Err(anyhow!("database not found")); }
        fs::remove_dir_all(self.db_path(name))?;
        Ok(())
    }

    pub fn list_databases(&self) -> Vec<String> {
        let dbs = self.dbs.lock().unwrap();
        let mut v: Vec<_> = dbs.keys().cloned().collect(); v.sort(); v
    }

    pub fn list_tables(&self, db: &str) -> Result<Vec<String>> {
        let dbs = self.dbs.lock().unwrap();
        let d = dbs.get(db).ok_or_else(|| anyhow!("database not found: {db}"))?;
        let mut v: Vec<_> = d.tables.keys().cloned().collect(); v.sort(); Ok(v)
    }

    pub fn execute(&self, db: Option<&str>, sql: &str) -> Result<QueryResult> {
        let s = sql.trim().trim_end_matches(';').trim();
        let upper = s.to_ascii_uppercase();

        if upper == "SHOW DATABASES" {
            return Ok(QueryResult::Rows {
                columns: vec!["Database".into()],
                rows: self.list_databases().into_iter().map(|x| vec![Value::Text(x)]).collect()
            });
        }
        if upper.starts_with("CREATE DATABASE ") {
            self.create_database(s[16..].trim())?;
            return Ok(QueryResult::Message("database created".into()));
        }
        if upper.starts_with("DROP DATABASE ") {
            self.drop_database(s[14..].trim())?;
            return Ok(QueryResult::Message("database dropped".into()));
        }
        if upper == "SHOW TABLES" {
            let db = db.ok_or_else(|| anyhow!("no database selected"))?;
            return Ok(QueryResult::Rows {
                columns: vec!["Table".into()],
                rows: self.list_tables(db)?.into_iter().map(|x| vec![Value::Text(x)]).collect()
            });
        }
        if upper.starts_with("CREATE TABLE ") {
            let db = db.ok_or_else(|| anyhow!("no database selected"))?;
            let re = Regex::new(r"(?i)^CREATE TABLE ([A-Za-z_][A-Za-z0-9_]*)\s*\((.+)\)$")?;
            let c = re.captures(s).ok_or_else(|| anyhow!("bad CREATE TABLE syntax"))?;
            let table = c[1].to_string();
            let mut columns = Vec::new();
            for part in c[2].split(',') {
                let p: Vec<_> = part.trim().split_whitespace().collect();
                if p.len()!=2 { return Err(anyhow!("column must be name TYPE")); }
                let ty = match p[1].to_ascii_uppercase().as_str() { "INT" => ColumnType::Int, "TEXT" => ColumnType::Text, _ => return Err(anyhow!("supported types: INT, TEXT")) };
                columns.push(Column{name:p[0].into(),ty});
            }
            let rec = WalRecord::CreateTable{db:db.into(),table:table.clone(),columns};
            self.append(&rec)?;
            self.apply_record(rec)?;
            return Ok(QueryResult::Message("table created".into()));
        }
        if upper.starts_with("DROP TABLE ") {
            let db = db.ok_or_else(|| anyhow!("no database selected"))?;
            let table=s[11..].trim().to_string();
            self.append(&WalRecord::DropTable{db:db.into(),table:table.clone()})?;
            self.apply_record(WalRecord::DropTable{db:db.into(),table})?;
            return Ok(QueryResult::Message("table dropped".into()));
        }
        if upper.starts_with("INSERT INTO ") {
            let db = db.ok_or_else(|| anyhow!("no database selected"))?;
            return self.insert(db,s);
        }
        if upper.starts_with("SELECT ") {
            let db = db.ok_or_else(|| anyhow!("no database selected"))?;
            return self.select(db,s);
        }
        if upper.starts_with("UPDATE ") {
            let db = db.ok_or_else(|| anyhow!("no database selected"))?;
            return self.update(db,s);
        }
        if upper.starts_with("DELETE FROM ") {
            let db = db.ok_or_else(|| anyhow!("no database selected"))?;
            return self.delete(db,s);
        }
        Err(anyhow!("unsupported SQL"))
    }

    fn get_table(&self, db:&str, table:&str)->Result<Table>{
        let dbs=self.dbs.lock().unwrap();
        Ok(dbs.get(db).ok_or_else(||anyhow!("database not found"))?.tables.get(table).ok_or_else(||anyhow!("table not found: {table}"))?.clone())
    }

    fn insert(&self, db:&str, s:&str)->Result<QueryResult>{
        let re=Regex::new(r"(?i)^INSERT INTO ([A-Za-z_][A-Za-z0-9_]*)\s*(?:\(([^)]*)\))?\s*VALUES\s*\((.*)\)$")?;
        let c=re.captures(s).ok_or_else(||anyhow!("bad INSERT syntax"))?;
        let table=&c[1]; let t=self.get_table(db,table)?;
        let names:Vec<String>=c.get(2).map(|m|m.as_str().split(',').map(|x|x.trim().to_string()).collect()).unwrap_or_else(||t.columns.iter().map(|x|x.name.clone()).collect());
        let vals=parse_values(c[3].trim())?;
        if names.len()!=vals.len(){return Err(anyhow!("column/value count mismatch"))}
        let mut row=Row::new();
        for col in &t.columns { row.insert(col.name.clone(),Value::Null); }
        for (n,v) in names.iter().zip(vals){ if !t.columns.iter().any(|x|x.name.eq_ignore_ascii_case(n)){return Err(anyhow!("unknown column: {n}"))} row.insert(n.clone(),v); }
        validate_row(&t,&row)?;
        self.append(&WalRecord::Insert{db:db.into(),table:table.into(),row:row.clone()})?;
        self.apply_record(WalRecord::Insert{db:db.into(),table:table.into(),row})?;
        Ok(QueryResult::Message("1 row inserted".into()))
    }

    fn select(&self,db:&str,s:&str)->Result<QueryResult>{
        let re=Regex::new(r"(?i)^SELECT\s+(.+?)\s+FROM\s+([A-Za-z_][A-Za-z0-9_]*)(?:\s+WHERE\s+(.+))?$")?;
        let c=re.captures(s).ok_or_else(||anyhow!("bad SELECT syntax"))?;
        let t=self.get_table(db,&c[2])?;
        let cols:Vec<String>=if c[1].trim()=="*" {t.columns.iter().map(|x|x.name.clone()).collect()} else {c[1].split(',').map(|x|x.trim().to_string()).collect()};
        let pred=c.get(3).map(|m|parse_where(m.as_str())).transpose()?;
        let mut out=vec![];
        for r in t.rows { if pred.as_ref().map(|p|matches_where(&r,p)).unwrap_or(true){out.push(cols.iter().map(|c|r.get(c).cloned().unwrap_or(Value::Null)).collect())}}
        Ok(QueryResult::Rows{columns:cols,rows:out})
    }

    fn update(&self,db:&str,s:&str)->Result<QueryResult>{
        let re=Regex::new(r"(?i)^UPDATE\s+([A-Za-z_][A-Za-z0-9_]*)\s+SET\s+(.+?)(?:\s+WHERE\s+(.+))?$")?;
        let c=re.captures(s).ok_or_else(||anyhow!("bad UPDATE syntax"))?;
        let table=&c[1]; let t=self.get_table(db,table)?;
        let assigns=parse_assignments(&c[2])?; let pred=c.get(3).map(|m|parse_where(m.as_str())).transpose()?;
        let mut count=0;
        for (i,old) in t.rows.iter().enumerate(){
            if pred.as_ref().map(|p|matches_where(old,p)).unwrap_or(true){
                let mut row=old.clone();
                for (k,v) in &assigns { row.insert(k.clone(),v.clone()); }
                validate_row(&t,&row)?;
                self.append(&WalRecord::Update{db:db.into(),table:table.into(),index:i,row:row.clone()})?;
                self.apply_record(WalRecord::Update{db:db.into(),table:table.into(),index:i,row})?; count+=1;
            }
        }
        Ok(QueryResult::Message(format!("{count} row(s) updated")))
    }

    fn delete(&self,db:&str,s:&str)->Result<QueryResult>{
        let re=Regex::new(r"(?i)^DELETE FROM\s+([A-Za-z_][A-Za-z0-9_]*)(?:\s+WHERE\s+(.+))?$")?;
        let c=re.captures(s).ok_or_else(||anyhow!("bad DELETE syntax"))?;
        let table=&c[1]; let t=self.get_table(db,table)?; let pred=c.get(2).map(|m|parse_where(m.as_str())).transpose()?;
        let mut idx=vec![];
        for (i,r) in t.rows.iter().enumerate(){if pred.as_ref().map(|p|matches_where(r,p)).unwrap_or(true){idx.push(i)}}
        for i in idx.iter().rev(){self.append(&WalRecord::Delete{db:db.into(),table:table.into(),index:*i})?;self.apply_record(WalRecord::Delete{db:db.into(),table:table.into(),index:*i})?;}
        Ok(QueryResult::Message(format!("{} row(s) deleted",idx.len())))
    }
}

#[derive(Debug)]
pub enum QueryResult { Message(String), Rows{columns:Vec<String>,rows:Vec<Vec<Value>>} }

#[derive(Debug)]
struct Condition(String,String,String);

fn parse_where(s:&str)->Result<Condition>{let re=Regex::new(r#"(?i)^\s*([A-Za-z_][A-Za-z0-9_]*)\s*(=|!=|<>|>|<)\s*(.+?)\s*$"#)?;let c=re.captures(s).ok_or_else(||anyhow!("bad WHERE"))?;Ok(Condition(c[1].into(),c[2].into(),c[3].into()))}
fn matches_where(r:&Row,c:&Condition)->bool{let Some(a)=r.get(&c.0) else{return false};let b=parse_literal(&c.2).unwrap_or(Value::Null);match c.1.as_str(){"="=>a==&b,"!="|"<>"=>a!=&b,_=>false}}
fn parse_assignments(s:&str)->Result<Vec<(String,Value)>>{s.split(',').map(|x|{let mut p=x.splitn(2,'=');Ok((p.next().ok_or_else(||anyhow!("bad assignment"))?.trim().into(),parse_literal(p.next().ok_or_else(||anyhow!("bad assignment"))?.trim())?))}).collect()}
fn parse_values(s:&str)->Result<Vec<Value>>{let mut out=vec![];let mut cur=String::new();let mut q=false;for ch in s.chars(){if ch=='\''{q=!q;cur.push(ch)}else if ch==','&&!q{out.push(parse_literal(cur.trim())?);cur.clear()}else{cur.push(ch)}}if !cur.trim().is_empty(){out.push(parse_literal(cur.trim())?)}Ok(out)}
fn parse_literal(s:&str)->Result<Value>{let s=s.trim();if s.eq_ignore_ascii_case("NULL"){return Ok(Value::Null)}if s.starts_with('\'')&&s.ends_with('\''){return Ok(Value::Text(s[1..s.len()-1].replace("''","'")))}Ok(Value::Int(s.parse().context("expected INT or quoted TEXT")?))}
fn validate_row(t:&Table,r:&Row)->Result<()> {for c in &t.columns{let v=r.get(&c.name).unwrap_or(&Value::Null);match (&c.ty,v){(ColumnType::Int,Value::Int(_))|(ColumnType::Int,Value::Null)|(ColumnType::Text,Value::Text(_))|(ColumnType::Text,Value::Null)=>{},_=>return Err(anyhow!("type mismatch for column {}",c.name))}}Ok(())}
fn valid_ident(s:&str)->bool{Regex::new(r"^[A-Za-z_][A-Za-z0-9_]*$").unwrap().is_match(s)}
