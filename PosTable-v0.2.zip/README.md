# PosTable v0.2

PosTable is a Rust SQL database prototype with a separate TCP server and persistent on-disk storage.

## Requirements
Rust stable + Cargo.

## Build
```bash
cargo build --release
```

## Run local database
```bash
cargo run --bin postable
```

Data is stored in `./data/<database>/wal.log`.

## Run server
```bash
cargo run --bin postable-server
```

Default port: `5433`.

A simple TCP client can connect and send one SQL command per line.

## Example
```sql
CREATE DATABASE demo;
USE demo;
CREATE TABLE users (id INT, name TEXT);
INSERT INTO users VALUES (1, 'Artem');
INSERT INTO users VALUES (2, 'Alice');
SELECT * FROM users;
SELECT id, name FROM users WHERE id = 1;
UPDATE users SET name = 'Bob' WHERE id = 2;
DELETE FROM users WHERE id = 1;
```

## Current architecture

- `Engine`: database engine
- WAL (`wal.log`): durable append-only write-ahead log
- `postable-server`: separate TCP server
- `postable`: local interactive CLI
- SQL subset: CREATE/DROP DATABASE, CREATE/DROP TABLE, INSERT, SELECT, UPDATE, DELETE, WHERE, SHOW

## Important
This is a real persistent database engine prototype, not yet a production replacement for PostgreSQL/MySQL. It intentionally lacks authentication, TLS, transactions, indexes, concurrent MVCC, query planning and crash-safe checkpoint compaction. Those are planned next.
